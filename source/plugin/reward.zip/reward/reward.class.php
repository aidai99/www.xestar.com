<?php 

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
 *折翼天使资源社区：www.zheyitianshi.com
 *更多商业插件/模版折翼天使资源社区 就在折翼天使资源社区
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
class plugin_reward {
	
	function  __construct() {
		
	}
}

class plugin_reward_forum extends plugin_reward{
	 
	function viewthread_useraction() {
		global $_G;
$ym_copyright = DB::fetch_first("select name,copyright from ".DB::table('common_plugin')." where identifier='reward'");
if(!strstr($ym_copyright['copyright'],base64_decode('eW1nNg==')) and !strstr($_G['siteurl'],base64_decode('MTI3LjAuMC4x')) and !strstr($_G['siteurl'],base64_decode('bG9jYWxob3N0'))){ echo '&#x672c;&#x5957;'.$ym_copyright['name'].'&#x63d2;&#x4ef6;&#x6765;&#x81ea;<a href="'.base64_decode('aHR0cDovL3d3dy55bWc2LmNvbS8=').'">&#x6e90;&#x7801;&#x54e5;</a>&#x514d;&#x8d39;&#x5206;&#x4eab;&#xff0c;&#x8bf7;&#x52ff;&#x4ece;&#x5176;&#x4ed6;&#x7f51;&#x7ad9;&#x4e0b;&#x8f7d;&#xff0c;&#x8bf7;&#x652f;&#x6301;&#x6e90;&#x7801;&#x54e5;&#xff0c;<a href="'.base64_decode('aHR0cDovL3d3dy55bWc2LmNvbS90aHJlYWQtODY1NS0xLTEuaHRtbA==').'">&#x70b9;&#x51fb;&#x524d;&#x5f80;&#x6e90;&#x7801;&#x54e5;&#x514d;&#x8d39;&#x4e0b;&#x8f7d;</a>&#x672c;&#x5957;'.$ym_copyright['name'].'&#x63d2;&#x4ef6;';exit;}
        $reward = $_G['cache']['plugin']['reward'];
		$reward['plate'] = unserialize($reward['plate']);
		$item;
		if($_G['fid'] && in_array($_G['fid'], $reward['plate'])){
			$extcredits = $_G['setting']['extcredits'][$reward['paytype']];
			$condition['tid'] = array(intval($_GET['tid']));
			$count = C::t('#reward#reward_log')->count_by_search($condition);
			foreach(C::t('#reward#reward_log')->fetch_all_by_search($condition,0,9) as $value){
				$item .= '<a href="home.php?mod=space&uid='.$value['uid'].'&do=profile" target="_blank" title="'.$value['username'].'"><dl><p>'.$extcredits['title'].'</p><b>'.$value['money'].'</b></dl>'.avatar($value['uid'],'small').'</a>';
			}
			//$bgcolor = $reward['bgcolor'] ? $reward['bgcolor'] : '#FCAD30';
			//$fontcolor = $reward['fontcolor'] ? $reward['fontcolor'] : '#FFF';
			include 'template/reward.htm';
			
			return $html;
		}
	}
	
}

/*
 *折翼天使资源社区：www.zheyitianshi.com
 *更多商业插件/模版折翼天使资源社区 就在折翼天使资源社区
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
class mobileplugin_reward {
	
	function  __construct() {
		
	}
}

class mobileplugin_reward_forum extends mobileplugin_reward{
	
	function viewthread_postbottom_mobile() {
		global $_G;
		$reward = $_G['cache']['plugin']['reward'];
		$reward['plate'] = unserialize($reward['plate']);

		if($_G['fid'] && in_array($_G['fid'], $reward['plate'])){
			$extcredits = $_G['setting']['extcredits'][$reward['paytype']];
			$condition['tid'] = array(intval($_GET['tid']));
			$count = C::t('#reward#reward_log')->count_by_search($condition);
			foreach(C::t('#reward#reward_log')->fetch_all_by_search($condition,0,5) as $value){
				$item .= '<a href="home.php?mod=space&uid='.$value['uid'].'&do=profile" title="'.$value['username'].'">'.avatar($value['uid'],'small').'</a>';
			}
			if($count){
			    $item .= '<a href="plugin.php?id=reward:misc&act=log&tid='.$_GET['tid'].'" class="log">'.lang('plugin/reward','RewardLog').'</a>';	
			}
			$bgcolor = $reward['bgcolor'] ? $reward['bgcolor'] : '#FCAD30';
			$fontcolor = $reward['fontcolor'] ? $reward['fontcolor'] : '#FFF';
			include 'template/touch/reward.htm';
			return $html;
		}
	}
	
}
?>